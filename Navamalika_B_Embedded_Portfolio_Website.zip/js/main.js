(function () {
  var btn = document.querySelector(".menu"), nav = document.getElementById("nav");
  btn.addEventListener("click", function () {
    var o = nav.classList.toggle("open"); btn.setAttribute("aria-expanded", o);
  });
  nav.addEventListener("click", function () { nav.classList.remove("open"); btn.setAttribute("aria-expanded", "false"); });
  document.getElementById("yr").textContent = new Date().getFullYear();

  var mon = document.getElementById("mon");
  var tasks = [["SensorTask", 2], ["ControlTask", 3], ["ButtonTask", 2], ["MonitorTask", 1]];
  var states = ["Blocked", "Ready", "Running"];
  function pad(s, n) { s = String(s); while (s.length < n) s += " "; return s; }
  function render(first) {
    var v = Math.floor(Math.random() * 4096), lines = [];
    lines.push('<span class="h">sensor=' + v + '  presses=' + (first ? 0 : Math.floor(Math.random() * 9)) + '  tasks=' + tasks.length + '</span>');
    lines.push('<span class="d">' + pad("task", 13) + pad("prio", 6) + pad("state", 9) + "stack free</span>");
    tasks.forEach(function (t, i) {
      lines.push(pad(t[0], 13) + pad(t[1], 6) + pad(states[(i + Math.floor(Math.random() * 3)) % 3], 9) + (1200 + Math.floor(Math.random() * 400)));
    });
    lines.push('<span class="d">' + (v > 2500 ? "red LED ON, buzzer ON" : "green LED ON, buzzer OFF") + "</span>");
    mon.innerHTML = lines.map(function (l, i) {
      return '<span class="ln" style="' + (first ? 'animation-delay:' + i * 0.25 + 's' : 'animation:none;opacity:1') + '">' + l + "</span>";
    }).join("");
  }
  render(true);
  if (!window.matchMedia("(prefers-reduced-motion: reduce)").matches) setInterval(function () { render(false); }, 2500);
})();
